import UIKit

/*
    50GB 100Tl
    Kota aşımından sonra her 1GB 4TL
 */

class Program
{
    func calculateQuota(a:Int) -> Int
    {
        var sum = 0
        
        if a>50
        {
            sum = ((a-50) * 4 + 100)
            print(sum)
        }
        else
        {
            print(100)
        }
        
        return sum
    }
}
let x = Program()
x.calculateQuota(a:80)

